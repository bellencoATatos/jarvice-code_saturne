var cs__halo__perio_8h =
[
    [ "cs_halo_perio_rotate_rij", "cs__halo__perio_8h.html#a96fd4b155bb75ec3cb6e3e2128b32bec", null ],
    [ "cs_halo_perio_sync_coords", "cs__halo__perio_8h.html#ab856e9fb88c0c980abe3240af1a2af64", null ],
    [ "cs_halo_perio_sync_var_diag_ni", "cs__halo__perio_8h.html#a92a708cffd09971ed8112ea18632e7c3", null ],
    [ "cs_halo_perio_sync_var_sym_tens", "cs__halo__perio_8h.html#a5efe824ed014ebeeb48555a5cd168ab2", null ],
    [ "cs_halo_perio_sync_var_sym_tens_grad", "cs__halo__perio_8h.html#af8be3e5ad1896f800774b65572235427", null ],
    [ "cs_halo_perio_sync_var_tens", "cs__halo__perio_8h.html#a9999a1c72cc3599eb97d37b0d07225ab", null ],
    [ "cs_halo_perio_sync_var_tens_ni", "cs__halo__perio_8h.html#a7a0346c8fefded5ba590312f0cdf2571", null ],
    [ "cs_halo_perio_sync_var_vect", "cs__halo__perio_8h.html#a6c3edbedf07f29db34167cc5639d3f08", null ],
    [ "cs_halo_perio_sync_var_vect_ni", "cs__halo__perio_8h.html#a34e27dab29c7840b6dd77c2e2f4e33da", null ],
    [ "perrte", "cs__halo__perio_8h.html#adc28147a141cf9ade664a2510f90d93d", null ]
];