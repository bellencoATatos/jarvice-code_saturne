var group__comp__properties =
[
    [ "iviscv", "group__comp__properties.html#gabea5f3dd996d69d4c5ccc28c7269dd1e", null ]
];