var cs__join__util_8c =
[
    [ "cs_join_build_edges_idx", "cs__join__util_8c.html#ae7e69b86f14c099db174cfc222d53898", null ],
    [ "cs_join_build_edges_lst", "cs__join__util_8c.html#ad426b3f172c35240bee4632f235c3636", null ],
    [ "cs_join_clean_selection", "cs__join__util_8c.html#a7f4b7641857c1cdb9da118f1fa74aaa4", null ],
    [ "cs_join_create", "cs__join__util_8c.html#a7f0a550f0909bcb9485be685291bc85f", null ],
    [ "cs_join_destroy", "cs__join__util_8c.html#a81a62718266a0d6d9b8d3d5bb08a120c", null ],
    [ "cs_join_extract_vertices", "cs__join__util_8c.html#af97fbb1ecd424cb6afaaefd963e14187", null ],
    [ "cs_join_select_create", "cs__join__util_8c.html#ae4f7169696f2c5a03b360ae0bb426f8c", null ],
    [ "cs_join_select_destroy", "cs__join__util_8c.html#ae0f2fe5a275720b3cf27f39391be1634", null ]
];