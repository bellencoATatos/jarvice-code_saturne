var group__lagran =
[
    [ "Lagrangian arrays", "group__lag__arrays.html", "group__lag__arrays" ],
    [ "Base", "group__base.html", "group__base" ],
    [ "Lagrangian source term pointers", "group__lag__st__pointers.html", "group__lag__st__pointers" ]
];