var group__additional__source__terms =
[
    [ "iporos", "group__additional__source__terms.html#ga618532832ddbb8e3d24a8bf97bb4d9f1", null ],
    [ "ncpdct", "group__additional__source__terms.html#ga9f4fae2a587b8f327b92ca4d8549f8dd", null ],
    [ "nctsmt", "group__additional__source__terms.html#ga825a2fc2e4ee3e4a93cfff40058b297e", null ],
    [ "nftcdt", "group__additional__source__terms.html#ga206ea0ddacfd2a9247bb39ca62c39aa7", null ]
];