var cs__ext__neighborhood_8h =
[
    [ "cs_ext_neighborhood_type_t", "cs__ext__neighborhood_8h.html#a1c14b13c5dacc1835a4387d3e75fa074", [
      [ "CS_EXT_NEIGHBORHOOD_NONE", "cs__ext__neighborhood_8h.html#a1c14b13c5dacc1835a4387d3e75fa074af22145e0851ab431b13f841a5453ce70", null ],
      [ "CS_EXT_NEIGHBORHOOD_COMPLETE", "cs__ext__neighborhood_8h.html#a1c14b13c5dacc1835a4387d3e75fa074a99dc6deee1b39f4aaf5faacd85e784c7", null ],
      [ "CS_EXT_NEIGHBORHOOD_CELL_CENTER_OPPOSITE", "cs__ext__neighborhood_8h.html#a1c14b13c5dacc1835a4387d3e75fa074ac13c9eb0c4b3a71679c9f19d40c53343", null ],
      [ "CS_EXT_NEIGHBORHOOD_NON_ORTHO_MAX", "cs__ext__neighborhood_8h.html#a1c14b13c5dacc1835a4387d3e75fa074a627e312883e1078a93d73171385b104d", null ]
    ] ],
    [ "cs_ext_neighborhood_define", "cs__ext__neighborhood_8h.html#ae59b2979fbb971a2ea6a72c6204b1822", null ],
    [ "cs_ext_neighborhood_get_non_ortho_max", "cs__ext__neighborhood_8h.html#aa774dafa572093a202d656e114ac1d60", null ],
    [ "cs_ext_neighborhood_get_type", "cs__ext__neighborhood_8h.html#a445898d2a74170a0a29415159ebe4d6c", null ],
    [ "cs_ext_neighborhood_reduce", "cs__ext__neighborhood_8h.html#af81dc71bc3176c28d9b8c563fbb43f78", null ],
    [ "cs_ext_neighborhood_set_non_ortho_max", "cs__ext__neighborhood_8h.html#a75c65dcc01323901480e67972a643461", null ],
    [ "cs_ext_neighborhood_set_type", "cs__ext__neighborhood_8h.html#ad55b5bdb9903567a4cc354e2f0546296", null ],
    [ "cs_ext_neighborhood_type_name", "cs__ext__neighborhood_8h.html#a6818137b05dce77580a77bd60824338e", null ]
];