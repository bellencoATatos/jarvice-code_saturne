var bft__mem__usage_8h =
[
    [ "bft_mem_usage_end", "bft__mem__usage_8h.html#acc110d327b53cbca649bc0dd28bc140b", null ],
    [ "bft_mem_usage_init", "bft__mem__usage_8h.html#a6b0346e436acf9d7c85c2d7ed3a01cb6", null ],
    [ "bft_mem_usage_initialized", "bft__mem__usage_8h.html#a74c8f3472103bfcd9d409ae4c9ddacf5", null ],
    [ "bft_mem_usage_max_pr_size", "bft__mem__usage_8h.html#a8efe61325c6400cd5c43f838a11d5548", null ],
    [ "bft_mem_usage_max_vm_size", "bft__mem__usage_8h.html#a9ef5607d6eab3cd3de25cdd43b4bf225", null ],
    [ "bft_mem_usage_n_calls", "bft__mem__usage_8h.html#a1b7d486bc9303cac21e7324928e0f0e6", null ],
    [ "bft_mem_usage_pr_size", "bft__mem__usage_8h.html#a6e061fcd5ed4b56bc87c1dad24e38919", null ],
    [ "bft_mem_usage_shared_lib_size", "bft__mem__usage_8h.html#a29a19dc895674a7af70bca244960bea8", null ]
];