var cs__physical__model_8h =
[
    [ "cs_physical_model_type_t", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8", [
      [ "CS_PHYSICAL_MODEL_FLAG", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8abe553658bf19ab4bbf08e798395587f4", null ],
      [ "CS_COMBUSTION_3PT", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8a2bba4bdf0dbff406b499313e6b8abfae", null ],
      [ "CS_COMBUSTION_EBU", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8a319cc1ad6db88973db9e461118b9bc25", null ],
      [ "CS_COMBUSTION_LW", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8a14c87aa69b13f279063984a06484f153", null ],
      [ "CS_COMBUSTION_PCLC", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8a7677a7dd0c01df2c079e7465ec3d4c45", null ],
      [ "CS_COMBUSTION_COAL", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8a68f493118520c02d1298da1cfcdf69c0", null ],
      [ "CS_COMBUSTION_FUEL", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8ace84d329926bb672c29a56dba854fc3e", null ],
      [ "CS_JOULE_EFFECT", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8a83ab5942ba0f9962d62440a724c55841", null ],
      [ "CS_ELECTRIC_ARCS", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8ab755e86c5f91addb5e989e3839301e85", null ],
      [ "CS_COMPRESSIBLE", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8a81dbe21b89ca8daa8726f71ab4860dea", null ],
      [ "CS_ATMOSPHERIC", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8aa245dadd3929f91fd54450b0f1b647cc", null ],
      [ "CS_COOLING_TOWERS", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8ab74e09a3b6ba373b1c4481e38a7edb14", null ],
      [ "CS_GAS_MIX", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8ae2109405e87cf13cf91bc846a4bd7516", null ],
      [ "CS_GROUNDWATER", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8a9aa8e15d58423ef719021939bf4e4a2c", null ],
      [ "CS_N_PHYSICAL_MODEL_TYPES", "cs__physical__model_8h.html#a1fa18d8db2229cde6f8e81e3d65fb0f8a098ecc7e35257b60e4422ccc2f1f7053", null ]
    ] ],
    [ "cs_glob_physical_model_flag", "cs__physical__model_8h.html#aa6ce8329d531bd517fb38c07282eac52", null ]
];