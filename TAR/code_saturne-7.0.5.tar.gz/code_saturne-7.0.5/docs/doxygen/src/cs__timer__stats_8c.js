var cs__timer__stats_8c =
[
    [ "_POSIX_C_SOURCE", "cs__timer__stats_8c.html#a3024ccd4a9af5109d24e6c57565d74a1", null ],
    [ "cs_timer_stats_add_diff", "cs__timer__stats_8c.html#ac4c18a05673aad6f615e9beedfdaddff", null ],
    [ "cs_timer_stats_create", "cs__timer__stats_8c.html#ab181c2f8d2cc60dca9117774c1750e79", null ],
    [ "cs_timer_stats_define_defaults", "cs__timer__stats_8c.html#a9fe839ba8d6f9343556fb95e14767699", null ],
    [ "cs_timer_stats_finalize", "cs__timer__stats_8c.html#ac5991023220df9ee8bb8601e09db9800", null ],
    [ "cs_timer_stats_id_by_name", "cs__timer__stats_8c.html#a1f29745ba2405c21c273675ce93444e1", null ],
    [ "cs_timer_stats_increment_time_step", "cs__timer__stats_8c.html#a9d278db8c7481d932bc15190158b5181", null ],
    [ "cs_timer_stats_initialize", "cs__timer__stats_8c.html#a3049fa9e4a61d36cb01a986068a6cf13", null ],
    [ "cs_timer_stats_is_active", "cs__timer__stats_8c.html#a6f30e7bb3d9f5bc6c72666159739927b", null ],
    [ "cs_timer_stats_set_plot", "cs__timer__stats_8c.html#aadee60bff91f32b40535d400cc16d1a2", null ],
    [ "cs_timer_stats_set_plot_options", "cs__timer__stats_8c.html#ac2b1f972ef9a9951cdc5851285d8f866", null ],
    [ "cs_timer_stats_set_start_time", "cs__timer__stats_8c.html#ab86a53bf53fb7527868ca27c0e9f6c9e", null ],
    [ "cs_timer_stats_start", "cs__timer__stats_8c.html#aa4831446268719c734550ea044c55f4f", null ],
    [ "cs_timer_stats_stop", "cs__timer__stats_8c.html#a8e45f7419adf8f274b42b5eefd0750a5", null ],
    [ "cs_timer_stats_switch", "cs__timer__stats_8c.html#ad3006082f94eea6c14368b3683ead041", null ]
];