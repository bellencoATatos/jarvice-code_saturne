var group__numvar =
[
    [ "Main variables", "group__main__variables.html", "group__main__variables" ],
    [ "Physical properties", "group__physical__prop.html", "group__physical__prop" ],
    [ "Numerical properties", "group__numerical__prop.html", "group__numerical__prop" ],
    [ "Mapping to field structures", "group__field__map.html", "group__field__map" ],
    [ "gas_mix_options_init", "group__numvar.html#gac7331aa05a8564217ad8ba4fd0ffdea0", null ]
];