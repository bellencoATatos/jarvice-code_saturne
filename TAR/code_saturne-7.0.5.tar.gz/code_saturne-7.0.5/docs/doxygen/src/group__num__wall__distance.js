var group__num__wall__distance =
[
    [ "icdpar", "group__num__wall__distance.html#ga52caa58daece3da259df6301f5324c6e", null ],
    [ "imajdy", "group__num__wall__distance.html#ga114e9f6d3da1c017509b027c91f1ef59", null ],
    [ "ineedy", "group__num__wall__distance.html#ga8151c90fd9ab346fea89c6fe78cdb7e4", null ]
];