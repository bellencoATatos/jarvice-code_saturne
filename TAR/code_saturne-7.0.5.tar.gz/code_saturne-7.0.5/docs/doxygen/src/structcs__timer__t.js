var structcs__timer__t =
[
    [ "cpu_nsec", "structcs__timer__t.html#a6b4893f7e427d732a7f6028ec8fee75a", null ],
    [ "cpu_sec", "structcs__timer__t.html#a051e89a899e43f6bc1b60e8ccb8fa4ce", null ],
    [ "wall_nsec", "structcs__timer__t.html#a3cf38e5a34bc7396acababf0aa0b7ae0", null ],
    [ "wall_sec", "structcs__timer__t.html#a656ead7947cc397544b9088fb4ed058f", null ]
];