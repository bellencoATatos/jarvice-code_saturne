var cs__xdef__eval_8h =
[
    [ "cs_xdef_eval_t", "cs__xdef__eval_8h.html#afdfe7d14e5b8fe8e723f5b375d4fdcc0", null ],
    [ "cs_xdef_eval_at_b_faces_by_analytic", "cs__xdef__eval_8h.html#a6c0ae88d89f1d0bb92a6e2f6885f232a", null ],
    [ "cs_xdef_eval_at_b_faces_by_dof_func", "cs__xdef__eval_8h.html#a492fe7854656d5d128b8b1e914c40aec", null ],
    [ "cs_xdef_eval_at_cells_by_analytic", "cs__xdef__eval_8h.html#a50ec0dbc14870f9b905ea25c964ad1d8", null ],
    [ "cs_xdef_eval_at_cells_by_dof_func", "cs__xdef__eval_8h.html#a50e82e4c9fba3c390413550e2256443a", null ],
    [ "cs_xdef_eval_at_vertices_by_analytic", "cs__xdef__eval_8h.html#ac95ff0bcedad161940693406f763eecd", null ],
    [ "cs_xdef_eval_at_vertices_by_array", "cs__xdef__eval_8h.html#aa677e84974aaf775a48e09280d9556ac", null ],
    [ "cs_xdef_eval_at_vertices_by_dof_func", "cs__xdef__eval_8h.html#a33e61869a18ddd2605315951e0fe0f06", null ],
    [ "cs_xdef_eval_avg_at_b_faces_by_analytic", "cs__xdef__eval_8h.html#a723bc94be46ca59a78b93ba2bd141ec2", null ],
    [ "cs_xdef_eval_cell_by_field", "cs__xdef__eval_8h.html#ac76a322c5ad25dc8c12a2373f1efe5ca", null ],
    [ "cs_xdef_eval_nd_at_cells_by_array", "cs__xdef__eval_8h.html#a5e5086af907a40ba5a783c90bdec32e9", null ],
    [ "cs_xdef_eval_scalar_at_cells_by_array", "cs__xdef__eval_8h.html#a88fff5516e39b3844801681171a0d598", null ],
    [ "cs_xdef_eval_scalar_at_cells_by_time_func", "cs__xdef__eval_8h.html#a66e5b62f7561d0eb60ed47fdea678500", null ],
    [ "cs_xdef_eval_scalar_by_val", "cs__xdef__eval_8h.html#aa8fda397117ad2088d5bab776db017ac", null ],
    [ "cs_xdef_eval_symtens_at_cells_by_time_func", "cs__xdef__eval_8h.html#a410f9031f18dee33e7376b32d165c07a", null ],
    [ "cs_xdef_eval_symtens_by_val", "cs__xdef__eval_8h.html#a0cdf4dd7c54360b4e28aa6429c05d47f", null ],
    [ "cs_xdef_eval_tensor_at_cells_by_time_func", "cs__xdef__eval_8h.html#a97d18c2451c3801dd522787e78f6c277", null ],
    [ "cs_xdef_eval_tensor_by_val", "cs__xdef__eval_8h.html#ac60d6f25ddf1ca9325a42e49a0e16431", null ],
    [ "cs_xdef_eval_vector_at_cells_by_time_func", "cs__xdef__eval_8h.html#ad2d86d24d51b2b729131606932a5f17f", null ],
    [ "cs_xdef_eval_vector_by_val", "cs__xdef__eval_8h.html#a74df20fb0c3a73960e55b0eeca796c51", null ]
];