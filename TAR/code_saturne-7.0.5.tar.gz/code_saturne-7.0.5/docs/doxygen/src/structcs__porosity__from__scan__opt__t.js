var structcs__porosity__from__scan__opt__t =
[
    [ "compute_porosity_from_scan", "structcs__porosity__from__scan__opt__t.html#a0d36b7553a8ff98da6b56af2594e3db2", null ],
    [ "file_name", "structcs__porosity__from__scan__opt__t.html#a8505c513bc640d1f69e5f76fb32b24a8", null ],
    [ "nb_sources", "structcs__porosity__from__scan__opt__t.html#a8363745d431e1590b6081b48b205e4ca", null ],
    [ "output_name", "structcs__porosity__from__scan__opt__t.html#a5a9bef7fd18e086a326d8b76dbd359ef", null ],
    [ "postprocess_points", "structcs__porosity__from__scan__opt__t.html#a27965120275d936c11556a86a3e035e2", null ],
    [ "source_c_ids", "structcs__porosity__from__scan__opt__t.html#aca1dab2e0673bcbf29d0477d241ade3e", null ],
    [ "sources", "structcs__porosity__from__scan__opt__t.html#accb77f9ae98388f8a065c7f105126233", null ],
    [ "transformation_matrix", "structcs__porosity__from__scan__opt__t.html#a2454b672b54e3182fcc32bbdcfda8ad7", null ]
];