var structcs__turbulence__t =
[
    [ "compute", "structcs__turbulence__t.html#a7f0a150011b969614e92f17f7be0ac88", null ],
    [ "context", "structcs__turbulence__t.html#a261f9f58ccbeaa962c4e675e4212c9cc", null ],
    [ "free_context", "structcs__turbulence__t.html#a5578415f7462cb1a609ab6fd1b807c91", null ],
    [ "init_context", "structcs__turbulence__t.html#a7c98b917be88f201682f5328ef0f704b", null ],
    [ "mu_l", "structcs__turbulence__t.html#a1519456ff48356f9fc0d69d53016b998", null ],
    [ "mu_t", "structcs__turbulence__t.html#a7733eff1ba278d98cecbbfda1885d4a8", null ],
    [ "mu_t_field", "structcs__turbulence__t.html#a96495f3627c6e416edc1e646bc4384ee", null ],
    [ "mu_tot", "structcs__turbulence__t.html#afffcb91ed1143c662bfc5ef9ba0b2cef", null ],
    [ "mu_tot_array", "structcs__turbulence__t.html#ad994dba0cdb56ab3e0e00a99f4537d12", null ],
    [ "param", "structcs__turbulence__t.html#a51f20d6b1b54a2eee3be0e8adc96a0ae", null ],
    [ "rij", "structcs__turbulence__t.html#ad7c1a0792a4eb63da207b523f0e44ec4", null ],
    [ "update", "structcs__turbulence__t.html#a1586ef54a6e26a57539d06db6e6c78b5", null ]
];