var interfacerotation_1_1rotation__velocity =
[
    [ "rotation_velocity", "group__at__rotation.html#gaeaebd195aeaa8729d1347e2bbe950a20", null ]
];