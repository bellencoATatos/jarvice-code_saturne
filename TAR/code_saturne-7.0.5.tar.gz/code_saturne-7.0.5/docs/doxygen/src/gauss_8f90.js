var gauss_8f90 =
[
    [ "gauss", "gauss_8f90.html#aa9af90d5171ff781cb5e02b5477233fd", null ]
];