var cs__multigrid_8h =
[
    [ "cs_multigrid_t", "cs__multigrid_8h.html#a20ba2184cfbebea6a7afaf39591bcb9c", null ],
    [ "cs_multigrid_type_t", "cs__multigrid_8h.html#a3b23c80fb91f5738452a2eb9490cecc0", [
      [ "CS_MULTIGRID_V_CYCLE", "cs__multigrid_8h.html#a3b23c80fb91f5738452a2eb9490cecc0a9aa1b73d46f2515ceb7a5f43a13721a0", null ],
      [ "CS_MULTIGRID_K_CYCLE", "cs__multigrid_8h.html#a3b23c80fb91f5738452a2eb9490cecc0a282f405864331d8f27c4e9085e9347f5", null ],
      [ "CS_MULTIGRID_K_CYCLE_HPC", "cs__multigrid_8h.html#a3b23c80fb91f5738452a2eb9490cecc0a67db203fd60bd636b5f5bb1052fe2ea9", null ],
      [ "CS_MULTIGRID_N_TYPES", "cs__multigrid_8h.html#a3b23c80fb91f5738452a2eb9490cecc0a3e7048159d24ae3d0b69cbcbfe97b7f8", null ]
    ] ],
    [ "cs_multigrid_copy", "cs__multigrid_8h.html#a33b69b74a53eff794c6d4af250a45f6f", null ],
    [ "cs_multigrid_create", "cs__multigrid_8h.html#a586cefe9e8baa16ebce7005464de71c5", null ],
    [ "cs_multigrid_define", "cs__multigrid_8h.html#a4993f30a762e4861295da3196d6b0264", null ],
    [ "cs_multigrid_destroy", "cs__multigrid_8h.html#ae31eaf72dd1de54c61f0a5420a4ae146", null ],
    [ "cs_multigrid_error_post_and_abort", "cs__multigrid_8h.html#ab0c16c8b15b89024eaf9bb6de01b41fe", null ],
    [ "cs_multigrid_finalize", "cs__multigrid_8h.html#ad86a8eeaaf1bdbcbe9af780483423977", null ],
    [ "cs_multigrid_free", "cs__multigrid_8h.html#aa48e2ee74cd3c06682127002719b4a6c", null ],
    [ "cs_multigrid_get_fine_solver_type", "cs__multigrid_8h.html#a1a6ac0865f83f55f8596dfb4c851e10d", null ],
    [ "cs_multigrid_get_merge_options", "cs__multigrid_8h.html#a3d5b1ea120634a19f22e484fad957870", null ],
    [ "cs_multigrid_initialize", "cs__multigrid_8h.html#ab54bce1cea4866288f2f19a7b5078dad", null ],
    [ "cs_multigrid_log", "cs__multigrid_8h.html#ac40354b8b5e89bdeb5367868e154aa43", null ],
    [ "cs_multigrid_pc_create", "cs__multigrid_8h.html#a411b5a46918eb84a3c73003509a3d406", null ],
    [ "cs_multigrid_set_coarsening_options", "cs__multigrid_8h.html#a0b886dad4430cc25ae473702c0983bb8", null ],
    [ "cs_multigrid_set_merge_options", "cs__multigrid_8h.html#a81d0644403b2d62cad668bb0aa6d6f6e", null ],
    [ "cs_multigrid_set_plot_options", "cs__multigrid_8h.html#a9762eecfe0031676918305e0d0d37fa9", null ],
    [ "cs_multigrid_set_solver_options", "cs__multigrid_8h.html#aa3fcf31a4edfc5d849804b9e0b137c3e", null ],
    [ "cs_multigrid_setup", "cs__multigrid_8h.html#a0e4cf3fdd9e9d4815d15acbda7156021", null ],
    [ "cs_multigrid_setup_conv_diff", "cs__multigrid_8h.html#a368659c07ccf52a711fc428c55e2301d", null ],
    [ "cs_multigrid_solve", "cs__multigrid_8h.html#a2beadbb74d98a3299bf7b882b0d00580", null ],
    [ "cs_multigrid_type_name", "cs__multigrid_8h.html#adb7c93e65e03d5203327b3484735d519", null ]
];