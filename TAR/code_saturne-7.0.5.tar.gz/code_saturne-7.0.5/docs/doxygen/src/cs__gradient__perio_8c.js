var cs__gradient__perio_8c =
[
    [ "cs_gradient_perio_finalize", "cs__gradient__perio_8c.html#a09b3db0a363c6a47ab7209bf894109c4", null ],
    [ "cs_gradient_perio_init_rij", "cs__gradient__perio_8c.html#abdd3eed8a250dbb51cc83bd890ea9640", null ],
    [ "cs_gradient_perio_init_rij_tensor", "cs__gradient__perio_8c.html#ab2cedbdcd9c6f83d803e3e1d93e17aaa", null ],
    [ "cs_gradient_perio_initialize", "cs__gradient__perio_8c.html#a89ca2d703ee82708317a4cd693f0993d", null ],
    [ "cs_gradient_perio_process_rij", "cs__gradient__perio_8c.html#aa3a11f3ababad8efd299adc80c0f63a8", null ],
    [ "cs_gradient_perio_update_mesh", "cs__gradient__perio_8c.html#a535d121441bd8e999311008239867e92", null ],
    [ "perinr", "cs__gradient__perio_8c.html#aaa4f94863de037c315a32a0766dfb72c", null ]
];