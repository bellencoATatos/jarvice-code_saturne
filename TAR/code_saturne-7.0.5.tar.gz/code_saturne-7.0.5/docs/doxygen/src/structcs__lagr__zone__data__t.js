var structcs__lagr__zone__data__t =
[
    [ "elt_type", "structcs__lagr__zone__data__t.html#a1e3bed868b10c68276372b7d2c980df5", null ],
    [ "injection_set", "structcs__lagr__zone__data__t.html#a1c27ab6170faa545162791031e20b2cd", null ],
    [ "location_id", "structcs__lagr__zone__data__t.html#a8d9829c412f5fdfa877eb8bd7ea6aa13", null ],
    [ "n_injection_sets", "structcs__lagr__zone__data__t.html#ad075d053f6137287b8307809cff3cd9f", null ],
    [ "n_zones", "structcs__lagr__zone__data__t.html#a03856cab612318ed6afb8c50965e06f4", null ],
    [ "particle_flow_rate", "structcs__lagr__zone__data__t.html#ade557f4b03d6ba1197b0356e5152c163", null ],
    [ "zone_type", "structcs__lagr__zone__data__t.html#a54370668702158efd6a18203d38dd9be", null ]
];