var cs__grid_8h =
[
    [ "cs_grid_t", "cs__grid_8h.html#abfd972bccaecc63d7faca8bfede54151", null ],
    [ "cs_grid_coarsening_t", "cs__grid_8h.html#a49bbab92fdd3147e6b2f0b08666c2ca0", [
      [ "CS_GRID_COARSENING_DEFAULT", "cs__grid_8h.html#a49bbab92fdd3147e6b2f0b08666c2ca0a3c3d30dbc14a166d8079745b9750f16c", null ],
      [ "CS_GRID_COARSENING_SPD_DX", "cs__grid_8h.html#a49bbab92fdd3147e6b2f0b08666c2ca0ab290ab48cb1ec6e276602962baf505e1", null ],
      [ "CS_GRID_COARSENING_SPD_MX", "cs__grid_8h.html#a49bbab92fdd3147e6b2f0b08666c2ca0a151e4449ec0da480c5bcf407bc9618c4", null ],
      [ "CS_GRID_COARSENING_SPD_PW", "cs__grid_8h.html#a49bbab92fdd3147e6b2f0b08666c2ca0ac83c16c0d50ac27d1edcfd5197223bfb", null ],
      [ "CS_GRID_COARSENING_CONV_DIFF_DX", "cs__grid_8h.html#a49bbab92fdd3147e6b2f0b08666c2ca0a495a99edaa37ba78da44c1c3b7f17b5f", null ]
    ] ],
    [ "cs_grid_coarsen", "cs__grid_8h.html#a75ec7fe5f278c0f4cc1ae9c39302735a", null ],
    [ "cs_grid_coarsen_to_single", "cs__grid_8h.html#a4ae457a16bd4fcc5a5ba109af9a77b17", null ],
    [ "cs_grid_create_from_parent", "cs__grid_8h.html#aa2e40ed1f6ccf2414bc5b14b0a256da5", null ],
    [ "cs_grid_create_from_shared", "cs__grid_8h.html#a3c3a4c50dda8b80bbcd7b5912cf40354", null ],
    [ "cs_grid_destroy", "cs__grid_8h.html#ae87411f654d78e025375cc33a078eecc", null ],
    [ "cs_grid_dump", "cs__grid_8h.html#a2ec8af0a8dfa8f355c301cab33c06f2a", null ],
    [ "cs_grid_finalize", "cs__grid_8h.html#aed22639b6b57991d188b4af07ea58a68", null ],
    [ "cs_grid_free_quantities", "cs__grid_8h.html#aff1acce3abc62cef7f0e4a70b303040a", null ],
    [ "cs_grid_get_info", "cs__grid_8h.html#af8766fdb697e035b77bd3e666b5fef68", null ],
    [ "cs_grid_get_matrix", "cs__grid_8h.html#ae3f4ecf09173035be83a175e6438da92", null ],
    [ "cs_grid_get_n_cols_ext", "cs__grid_8h.html#a3e6bc7bc26763e9310af716a29bfda76", null ],
    [ "cs_grid_get_n_cols_max", "cs__grid_8h.html#acdbc84b5b3512773e337f6d20276ed87", null ],
    [ "cs_grid_get_n_g_rows", "cs__grid_8h.html#a809e6e1fe9955635ae9f2553660e0eb7", null ],
    [ "cs_grid_get_n_rows", "cs__grid_8h.html#a8e2c37f6b36b3eaf65f23f3800224917", null ],
    [ "cs_grid_project_diag_dom", "cs__grid_8h.html#aa75d1c8e9bb484d8de6ee7f2fed76b6e", null ],
    [ "cs_grid_project_row_num", "cs__grid_8h.html#a0474f72a181954b46f4dce4b95db4459", null ],
    [ "cs_grid_project_row_rank", "cs__grid_8h.html#ae5f87740ce1de33a6eb107f40d6cabec", null ],
    [ "cs_grid_project_var", "cs__grid_8h.html#a6f45a07f8d979359c0bb8d433a3609d2", null ],
    [ "cs_grid_prolong_row_var", "cs__grid_8h.html#a63d1ede243f180ff5df67d7c900838b6", null ],
    [ "cs_grid_restrict_row_var", "cs__grid_8h.html#af940bf7dfd74d2190734bd0818e38902", null ],
    [ "cs_grid_set_matrix_tuning", "cs__grid_8h.html#a8463b4614ed0198c3dd476fd1904fb3c", null ],
    [ "cs_grid_coarsening_type_name", "cs__grid_8h.html#a5b708d5a390a4dd3344decae138f14f6", null ]
];