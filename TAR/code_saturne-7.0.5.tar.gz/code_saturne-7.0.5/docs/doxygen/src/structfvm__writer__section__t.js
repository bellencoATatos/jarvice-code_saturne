var structfvm__writer__section__t =
[
    [ "continues_previous", "structfvm__writer__section__t.html#a199741d5132db8ea531774e8334a9cf7", null ],
    [ "extra_vertex_base", "structfvm__writer__section__t.html#a12f1f7fa11ba2f4cb0e934f3b6aaf268", null ],
    [ "next", "structfvm__writer__section__t.html#ae34f23a35f2381d8827edc5221a3c6c8", null ],
    [ "num_shift", "structfvm__writer__section__t.html#adc8aeb8ef8d7542eb5e57adb20e17b6a", null ],
    [ "section", "structfvm__writer__section__t.html#a342f81ae6ccd7fa6bdea9cb2c03fa912", null ],
    [ "type", "structfvm__writer__section__t.html#a31046a5360f04bf2c328435900093b96", null ]
];