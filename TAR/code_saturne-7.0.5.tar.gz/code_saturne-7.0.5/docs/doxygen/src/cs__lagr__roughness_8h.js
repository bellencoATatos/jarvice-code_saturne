var cs__lagr__roughness_8h =
[
    [ "cs_lagr_roughness_param_t", "structcs__lagr__roughness__param__t.html", "structcs__lagr__roughness__param__t" ],
    [ "cs_lagr_roughness_barrier", "cs__lagr__roughness_8h.html#ac9779bf58e8c0e8ba85063efc9322289", null ],
    [ "cs_lagr_roughness_finalize", "cs__lagr__roughness_8h.html#a561f434fc16455e6bee23bd3e5089966", null ],
    [ "roughness_init", "cs__lagr__roughness_8h.html#afc47f1b7b19e88f0e4ce8796824f3df0", null ],
    [ "cs_lagr_roughness_param", "cs__lagr__roughness_8h.html#aa5bb89868dfdaf95702ccbdf6902e921", null ]
];