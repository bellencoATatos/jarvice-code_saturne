var group__vof__masks =
[
    [ "CS_VOF_ENABLED", "group__vof__masks.html#gaa9a695861c8119cefb5baac7821be209", null ],
    [ "CS_VOF_FREE_SURFACE", "group__vof__masks.html#ga4fd91411596e2601771d1576ce6ea23c", null ],
    [ "CS_VOF_MERKLE_MASS_TRANSFER", "group__vof__masks.html#gab4ca352d5c2ed643ad1c058cff75f939", null ],
    [ "vof_enabled", "group__vof__masks.html#gab1c4be0c463c3706e3252c550c4af62d", null ],
    [ "vof_free_surface", "group__vof__masks.html#ga09fe4eb43d16ade92a2ca983fe7a5513", null ],
    [ "vof_merkle_mass_transfer", "group__vof__masks.html#ga4329b995bba67a99af31d4fd8a9078ea", null ]
];