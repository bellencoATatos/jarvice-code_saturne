var structcs__xdef__analytic__context__t =
[
    [ "free_input", "structcs__xdef__analytic__context__t.html#a36727eb8bdfdafb6dc15ae94866c51ae", null ],
    [ "func", "structcs__xdef__analytic__context__t.html#a3699148440db7bdde6e95e16092363d1", null ],
    [ "input", "structcs__xdef__analytic__context__t.html#a877535c3b6ffdf230bce90c82c597d17", null ],
    [ "z_id", "structcs__xdef__analytic__context__t.html#ad8892c887a1bbca69e9a03b43b238013", null ]
];