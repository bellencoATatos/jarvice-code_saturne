var group__dimens =
[
    [ "ndimfb", "group__dimens.html#ga15fae7fbd2e17e504aa45ee124cee743", null ],
    [ "nscal", "group__dimens.html#ga7eafcfac4bfc1df6ba68bd65028bca1f", null ],
    [ "nvar", "group__dimens.html#gae9f2660bf124b7d70a260fec0988be04", null ]
];