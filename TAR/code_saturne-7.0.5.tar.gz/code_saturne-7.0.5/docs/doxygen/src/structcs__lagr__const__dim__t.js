var structcs__lagr__const__dim__t =
[
    [ "ncharm2", "structcs__lagr__const__dim__t.html#a6a1574aae5689c48de1cd4ec8ca7ba39", null ],
    [ "ndlaim", "structcs__lagr__const__dim__t.html#a675c56e6fa5bdc05174f038cfe270a0a", null ],
    [ "nlayer", "structcs__lagr__const__dim__t.html#ad42968e08d7a6cdf23b637e61156a36d", null ],
    [ "nusbrd", "structcs__lagr__const__dim__t.html#afcf772e6787d61add10ca842a1cf5a91", null ]
];