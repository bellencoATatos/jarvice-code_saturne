var group__cavitation =
[
    [ "Vaporization/condensation model", "group__cav__source__term.html", "group__cav__source__term" ],
    [ "Interaction with turbulence", "group__cav__turbulence.html", "group__cav__turbulence" ],
    [ "Numerical parameters", "group__cav__numerics.html", "group__cav__numerics" ],
    [ "cs_cavitation_parameters_t", "structcs__cavitation__parameters__t.html", [
      [ "cdest", "group__cav__source__term.html#gaf0ad3085d23bfbc05978a2b562e22af3", null ],
      [ "cprod", "group__cav__source__term.html#ga0325b4c0793190c0cd82110cfb7f7a5b", null ],
      [ "icvevm", "group__cav__turbulence.html#ga2c2d3d667f22aaec1aa8b9cf6e3f7f17", null ],
      [ "itscvi", "group__cav__numerics.html#ga9344cac1c483b248fcddd5356f9f25a9", null ],
      [ "linf", "group__cav__source__term.html#gafedc7bc4a95e48a65ec54e0bb3e16fad", null ],
      [ "mcav", "group__cav__turbulence.html#ga0e31b58d9c4427695dab4e0b8dc97f68", null ],
      [ "presat", "group__cav__source__term.html#ga4ae949be04f64894db0e074124fcbbfc", null ],
      [ "uinf", "group__cav__source__term.html#ga59d53fd31a0976d24ad1dcef7bb89c1d", null ]
    ] ]
];