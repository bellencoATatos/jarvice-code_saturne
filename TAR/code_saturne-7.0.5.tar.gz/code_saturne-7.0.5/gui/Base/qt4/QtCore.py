"""
Provides QtCore classes and functions.
"""

QT_API = "PYQT4"

from PyQt4.QtCore import *
