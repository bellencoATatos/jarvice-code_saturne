"""
Provides QtGui classes and functions.
"""

QT_API = "PYQT4"

from PyQt4.QtGui import *
