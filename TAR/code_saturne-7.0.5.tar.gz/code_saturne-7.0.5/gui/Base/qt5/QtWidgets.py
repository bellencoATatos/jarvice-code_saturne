"""
Provides QtWidgets classes and functions.
"""

QT_API = "PYQT5"

from PyQt5.QtWidgets import *
