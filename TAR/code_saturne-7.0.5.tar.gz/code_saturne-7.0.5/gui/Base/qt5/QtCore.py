"""
Provides QtCore classes and functions.
"""

QT_API = "PYQT5"

from PyQt5.QtCore import *
