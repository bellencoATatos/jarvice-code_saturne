"""
Provides QtGui classes and functions.
"""

QT_API = "PYQT5"

from PyQt5.QtGui import *
